# Portif-lio

canal João Carlos Lima e Silva

## Tarefas

o controle das tarefas desse projeto será realizado no github


## Icones

- :package: Nova funcionalidade
- :up: Atualização
- :beetle: Correção de bug
- :checkered_flag: release